# Product Requirements

## Personas
- Student
- ML Engineer
- Startup Developer

## User Story
As a user, I upload a `.forge` package and receive a working REST API without writing Docker or FastAPI.

## Functional Requirements
1. Upload package
2. Validate package
3. Generate API
4. Build Docker image
5. Deploy container
6. View logs
7. View metrics
8. Manage versions

## Non-functional
- Modular
- Testable
- Self-hosted
- Extensible
