# Project Charter

## Vision
ForgeML is a self-hosted platform that converts packaged machine learning models into production-ready APIs with minimal infrastructure knowledge.

## Mission
Provide a clean, modular deployment platform focused on a single-server MVP.

## Goals
- Standardize model packaging
- Automate deployment
- Generate APIs
- Provide monitoring
- Support version history

## Non-goals
- Kubernetes
- Distributed systems
- MLflow
- DVC
- Marketplace
- Multi-tenancy

## Success Criteria
A user can upload a `.forge` package and receive a running prediction endpoint within minutes.
