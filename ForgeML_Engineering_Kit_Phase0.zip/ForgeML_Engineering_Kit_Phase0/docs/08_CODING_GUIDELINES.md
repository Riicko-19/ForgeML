# Coding Guidelines

Python:
- FastAPI
- SQLAlchemy
- Pydantic v2

Frontend:
- Next.js
- TypeScript
- Tailwind
- shadcn/ui

Formatting:
- Ruff
- Black
- ESLint
- Prettier
