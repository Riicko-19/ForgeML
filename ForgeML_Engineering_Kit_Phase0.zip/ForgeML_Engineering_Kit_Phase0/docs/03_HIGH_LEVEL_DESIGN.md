# High Level Design

Subsystems:
- Frontend
- Backend
- Package Service
- Deployment Engine
- Runtime Manager
- Monitoring
- Persistence

Each subsystem owns its interfaces and communicates through services.
