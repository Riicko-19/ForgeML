# Repository

```text
backend/
frontend/
docs/
tests/
uploads/
storage/
.skills/
```

Backend layout:
api/
core/
package/
deployment/
runtime/
monitoring/
database/
