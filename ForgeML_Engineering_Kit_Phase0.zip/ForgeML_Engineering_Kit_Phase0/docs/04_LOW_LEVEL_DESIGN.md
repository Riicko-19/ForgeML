# Low Level Design

Modules
- package/
- analyzer/
- api_generator/
- deployment/
- runtime/
- monitoring/
- database/

Every module must contain:
- interfaces
- services
- models
- tests
- docs
