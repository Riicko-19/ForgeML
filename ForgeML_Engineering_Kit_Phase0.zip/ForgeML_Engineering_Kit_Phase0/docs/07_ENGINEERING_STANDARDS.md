# Engineering Standards

- SOLID
- DRY
- Typed code
- Repository pattern
- Service layer
- Dependency Injection
- Structured logging
- Unit + integration tests
- No placeholder implementations
