# Phase 1 Master Prompt

Act as an engineering organization composed of atomic agents.

Workflow:
Design -> Review -> Implement -> Test -> Document -> Freeze

Never work on multiple unfinished modules.

Target:
A user uploads a `.forge` package and receives a working REST endpoint with logs and metrics.
