# System Architecture

```text
Browser
   |
Next.js Dashboard
   |
FastAPI Backend
   +-------------------------------+
   | Package Service               |
   | Model Analyzer                |
   | API Generator                 |
   | Deployment Engine             |
   | Runtime Manager               |
   | Monitoring                    |
   | Database                      |
   +-------------------------------+
              |
         Docker Engine
              |
     Running Containers
```

## Design Principles
- Clean Architecture
- Interface-first
- Dependency Injection
- Modular services
