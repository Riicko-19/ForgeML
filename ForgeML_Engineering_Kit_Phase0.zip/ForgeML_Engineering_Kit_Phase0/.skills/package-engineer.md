# package-engineer

## Mission
Own this domain exclusively.

## Responsibilities
- Design
- Implement
- Test
- Document

## Owned Areas
Define and maintain interfaces for this domain.

## Acceptance
All tests pass, docs updated, interfaces stable before handoff.
