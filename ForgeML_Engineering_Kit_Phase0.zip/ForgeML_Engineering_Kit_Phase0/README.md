# ForgeML Engineering Kit (Phase 0)

This kit defines the architecture and planning artifacts required before implementation.

Contents:
- docs/
- diagrams/
- .skills/

Implementation begins only after these documents are reviewed.
